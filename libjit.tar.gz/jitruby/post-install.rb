require 'generate_rdoc'

generate_rdoc('--ri-site')

